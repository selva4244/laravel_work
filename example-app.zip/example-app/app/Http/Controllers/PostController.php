<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Posts;

class PostController extends Controller
{
    public function addPost(){
        return view('posts.add');
    }

    public function addComment($pid = null){

        return view('posts.comments',compact('pid'));
    }
    //Store image
    public function storePost(Request $request){
       /*Logic to store data*/
       $data= new Posts();

        if($request->file('image')){
            $file= $request->file('image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('public/Image'), $filename);
            $data['image']= $filename;
            $data['title']= $request->title;
            $data['content']= $request->content;
            $data['user_id']= auth()->user()->id;

        }
        $data->save();
        return redirect()->route('posts.view');
    }
        //View image
    public function viewPost(){
        //return view('posts.view');
        $postData= Posts::all();
        return view('posts.view', compact('postData'));
    }
}
