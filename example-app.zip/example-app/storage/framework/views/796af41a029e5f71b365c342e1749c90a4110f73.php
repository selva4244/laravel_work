
  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Posts')); ?></div>
  
                <div class="card-body">
                    
                        <form method="post" action="<?php echo e(route('posts.store')); ?>" 
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="image">
      <label>Title</label>
      <input type="text" class="form-control" required name="title">
    </div>
    <br>
    <div class="image">
      <label>Image</label>
      <input type="file" class="form-control" required name="image">
    </div>
    <br>
    <div class="image">
      <label>Content</label>
      <textarea class="form-control" required name="content"></textarea>
    </div>
    <br>

    <div class="post_button">
      <button type="submit" class="btn btn-success">Add</button>
    </div>
  </form>
  
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/posts/add.blade.php ENDPATH**/ ?>