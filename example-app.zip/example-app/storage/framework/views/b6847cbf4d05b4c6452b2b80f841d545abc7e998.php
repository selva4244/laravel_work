

  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('View All Posts')); ?></div>
  
                <div class="card-body">
                    
                        <h3>View All Posts</h3><hr>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Post Id</th>
          <th scope="col">User Id</th>
          <th scope="col">Title</th>
          <th scope="col">Image</th>
          <th scope="col">Content</th>
          <th scope="col">Comment</th>

        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $postData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($data->id); ?></td>
          <td><?php echo e($data->user_id); ?></td>
          <td><?php echo e($data->title); ?></td>

          <td>
       <img src="<?php echo e(url('public/Image/'.$data->image)); ?>"
 style="height: 100px; width: 150px;">
    </td>
    <td><?php echo e($data->content); ?></td>
    <th scope="col"><a class="btn btn-primary" data-pid="" href="<?php echo e(route('posts.comments', [$data->id])); ?>">Comment</a></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/posts/view.blade.php ENDPATH**/ ?>