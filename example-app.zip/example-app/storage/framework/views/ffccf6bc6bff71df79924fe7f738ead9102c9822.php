
  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Comments')); ?></div>
  
                <div class="card-body">

                    <h5>Post Id - <?php echo e($request->param); ?></h5>
                    
                        <form method="post" action="<?php echo e(route('store.comments')); ?>" >
    <?php echo csrf_field(); ?>
    
    <div class="image">
      <label>Comment</label>
      <textarea class="form-control" required name="comment"></textarea>
    </div>
    <br>

    <div class="post_button">
      <button type="submit" class="btn btn-success">Add</button>
    </div>
  </form>
  
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/posts/comments.blade.php ENDPATH**/ ?>