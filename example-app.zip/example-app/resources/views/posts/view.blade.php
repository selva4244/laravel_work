
@extends('layout')
  
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('View All Posts') }}</div>
  
                <div class="card-body">
                    
                        <h3>View All Posts</h3><hr>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Post Id</th>
          <th scope="col">User Id</th>
          <th scope="col">Title</th>
          <th scope="col">Image</th>
          <th scope="col">Content</th>
          <th scope="col">Comment</th>

        </tr>
      </thead>
      <tbody>
        @foreach($postData as $data)
        <tr>
          <td>{{$data->id}}</td>
          <td>{{$data->user_id}}</td>
          <td>{{$data->title}}</td>

          <td>
       <img src="{{ url('public/Image/'.$data->image) }}"
 style="height: 100px; width: 150px;">
    </td>
    <td>{{$data->content}}</td>
    <th scope="col"><a class="btn btn-primary" data-pid="" href="{{ route('add-comment', [$data->id]) }}">Comment</a></th>
        </tr>
        @endforeach
      </tbody>
    </table>
  
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

