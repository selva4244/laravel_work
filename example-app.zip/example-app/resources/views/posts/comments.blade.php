@extends('layout')
  
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Add Comments') }}</div>
  
                <div class="card-body">

                    <h5>Post Id - </h5>
                    
                        <form method="post" action="{{ route('store.comments') }}" >
    @csrf
    
    <div class="image">
      <label>Comment</label>
      <textarea class="form-control" required name="comment"></textarea>
    </div>
    <br>

    <div class="post_button">
      <button type="submit" class="btn btn-success">Add</button>
    </div>
  </form>
  
                </div>
            </div>
        </div>
    </div>
</div>


@endsection