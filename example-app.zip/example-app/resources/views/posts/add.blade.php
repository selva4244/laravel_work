@extends('layout')
  
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Add Posts') }}</div>
  
                <div class="card-body">
                    
                        <form method="post" action="{{ route('posts.store') }}" 
    enctype="multipart/form-data">
    @csrf
    <div class="image">
      <label>Title</label>
      <input type="text" class="form-control" required name="title">
    </div>
    <br>
    <div class="image">
      <label>Image</label>
      <input type="file" class="form-control" required name="image">
    </div>
    <br>
    <div class="image">
      <label>Content</label>
      <textarea class="form-control" required name="content"></textarea>
    </div>
    <br>

    <div class="post_button">
      <button type="submit" class="btn btn-success">Add</button>
    </div>
  </form>
  
                </div>
            </div>
        </div>
    </div>
</div>


@endsection